import React from "react";
function Info(){
  return(
   <div className ="note">
      <h2> Javascript and REACTJS</h2>
      <p1>basic web dev reactjs</p1>
      </div>
    
   
  );
}
export default Info;
