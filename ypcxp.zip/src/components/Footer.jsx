import React from "react";
function Footer(){
  return(
    <footer><p>
      Copyright by SHAPEAI @{new Date().getFullYear()}
      </p></footer>
  );
}
export default Footer;